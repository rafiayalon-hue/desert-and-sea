from sqlalchemy import Column, String, Integer, Float, Boolean, DateTime, Text, Enum, ForeignKey
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime
import enum

Base = declarative_base()


class BookingStatus(str, enum.Enum):
    confirmed = "confirmed"
    cancelled = "cancelled"


class CancellationTag(str, enum.Enum):
    internal_block = "internal_block"   # חסימה פנימית (רפי/אבישג)
    guest_cancel   = "guest_cancel"     # ביטול אורח
    direct_switch  = "direct_switch"    # מעבר ישיר מ-Airbnb


class BookingSource(str, enum.Enum):
    direct  = "direct"
    website = "website"
    airbnb  = "airbnb"
    other   = "other"


class Language(str, enum.Enum):
    he = "he"
    en = "en"
    es = "es"
    fr = "fr"


class PaymentMethod(str, enum.Enum):
    credit_link = "credit_link"   # לינק ישראכרט
    cash        = "cash"          # מזומן
    bank        = "bank"          # העברה בנקאית


class Booking(Base):
    __tablename__ = "bookings"

    id              = Column(String, primary_key=True)  # מספר הזמנה מ-MiniHotel
    first_name      = Column(String, nullable=False)
    last_name       = Column(String, default="")
    email           = Column(String, default="")
    phone           = Column(String, default="")
    country         = Column(String, default="IL")
    language        = Column(Enum(Language), nullable=True)  # נבחר ידנית

    checkin         = Column(DateTime, nullable=False)
    checkout        = Column(DateTime, nullable=False)
    nights          = Column(Integer, default=0)
    checkin_time    = Column(String, default="15:00")  # override מ-UI
    checkout_time   = Column(String, default="11:00")  # override מ-UI

    rooms           = Column(String, default="")       # "desert" / "sea" / "desert,sea"
    is_combined     = Column(Boolean, default=False)   # נכס משולב Des_Sea

    adults          = Column(Integer, default=0)
    children        = Column(Integer, default=0)

    source          = Column(Enum(BookingSource), default=BookingSource.direct)
    status          = Column(Enum(BookingStatus), default=BookingStatus.confirmed)
    cancellation_tag = Column(Enum(CancellationTag), nullable=True)

    total_price     = Column(Float, default=0)
    balance         = Column(Float, default=0)
    payment_method  = Column(Enum(PaymentMethod), nullable=True)
    payment_link    = Column(String, nullable=True)    # לינק ישראכרט ידני

    ttlock_code     = Column(String, nullable=True)    # קוד 4 ספרות
    ttlock_passcode_id = Column(String, nullable=True) # ID מ-TTLock למחיקה

    notes           = Column(Text, default="")
    internal_notes  = Column(Text, default="")         # הערות פנימיות בדשבורד בלבד

    minihotel_raw   = Column(Text, default="")         # JSON גולמי מ-MiniHotel

    created_at      = Column(DateTime, default=datetime.utcnow)
    updated_at      = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_synced_at  = Column(DateTime, nullable=True)

    # Relations
    backup_guest    = relationship("BackupGuest", back_populates="booking", uselist=False)
    messages        = relationship("MessageLog", back_populates="booking")


class BackupGuest(Base):
    """הזמנת גיבוי — מנוהלת בדשבורד בלבד, לא נשלחת למיניהוטל"""
    __tablename__ = "backup_guests"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    booking_id      = Column(String, ForeignKey("bookings.id"), nullable=False)
    first_name      = Column(String, nullable=False)
    last_name       = Column(String, default="")
    phone           = Column(String, default="")
    email           = Column(String, default="")
    language        = Column(Enum(Language), nullable=True)
    notes           = Column(Text, default="")
    is_activated    = Column(Boolean, default=False)  # האם הפך להזמנה רשמית
    created_at      = Column(DateTime, default=datetime.utcnow)

    booking         = relationship("Booking", back_populates="backup_guest")


class MessageType(str, enum.Enum):
    booking_confirmation = "booking_confirmation"  # הודעה 1
    pre_arrival          = "pre_arrival"           # הודעה 2
    checkin_code         = "checkin_code"          # הודעה 3
    checkout_payment     = "checkout_payment"      # הודעה 4
    review_request       = "review_request"        # הודעה 5
    manual               = "manual"                # ידני


class MessageLog(Base):
    __tablename__ = "message_logs"

    id          = Column(Integer, primary_key=True, autoincrement=True)
    booking_id  = Column(String, ForeignKey("bookings.id"), nullable=False)
    msg_type    = Column(Enum(MessageType), nullable=False)
    language    = Column(Enum(Language), nullable=False)
    phone       = Column(String, nullable=False)
    body        = Column(Text, nullable=False)
    status      = Column(String, default="pending")   # pending/sent/failed
    twilio_sid  = Column(String, nullable=True)
    sent_at     = Column(DateTime, nullable=True)
    error       = Column(Text, nullable=True)
    created_at  = Column(DateTime, default=datetime.utcnow)

    booking     = relationship("Booking", back_populates="messages")


class AppSettings(Base):
    """הגדרות ניתנות לשינוי מה-UI"""
    __tablename__ = "app_settings"

    key         = Column(String, primary_key=True)
    value       = Column(String, nullable=False)
    updated_at  = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # ערכי ברירת מחדל:
    # checkin_time  = "15:00"
    # checkout_time = "11:00"
    # pre_arrival_days = "2"
    # msg_template_he_1 = "..."
    # msg_template_en_1 = "..."
    # וכן הלאה
