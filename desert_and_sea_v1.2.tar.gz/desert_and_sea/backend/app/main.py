from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api.routes import bookings, guests, locks, messages, settings
from app.tasks.scheduler import start_scheduler

app = FastAPI(
    title="Desert and Sea — דשבורד ניהול צימרים",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(bookings.router, prefix="/api/bookings", tags=["bookings"])
app.include_router(guests.router,   prefix="/api/guests",   tags=["guests"])
app.include_router(locks.router,    prefix="/api/locks",    tags=["locks"])
app.include_router(messages.router, prefix="/api/messages", tags=["messages"])
app.include_router(settings.router, prefix="/api/settings", tags=["settings"])

@app.on_event("startup")
async def startup():
    start_scheduler()

@app.get("/api/health")
async def health():
    return {"status": "ok", "service": "Desert and Sea"}
