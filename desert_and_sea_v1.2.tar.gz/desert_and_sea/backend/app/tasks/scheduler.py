"""
Scheduler — APScheduler
------------------------
משימות אוטומטיות:
1. סנכרון MiniHotel — כל שעה
2. הודעות לפני הגעה — 09:00 כל יום (2 ימים מראש)
3. הודעות כניסה — 09:00 ביום הכניסה
4. הודעות יציאה — 09:00 ביום היציאה
5. הודעות ביקורת — 14:00 ביום היציאה
"""
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)
scheduler = AsyncIOScheduler(timezone="Asia/Jerusalem")


async def task_sync_minihotel():
    """סנכרון הזמנות מ-MiniHotel"""
    from app.integrations.minihotel import minihotel_client
    try:
        bookings = await minihotel_client.get_bookings(
            date_from=datetime.now(),
            date_to=datetime.now() + timedelta(days=180)
        )
        logger.info(f"[Sync] סונכרנו {len(bookings)} הזמנות")
    except Exception as e:
        logger.error(f"[Sync] שגיאה: {e}")


async def task_send_pre_arrival():
    """הודעות לפני הגעה — יומיים מראש"""
    from app.integrations.minihotel import minihotel_client
    from app.integrations.whatsapp import whatsapp_service

    target_date = (datetime.now() + timedelta(days=2)).strftime("%Y-%m-%d")
    bookings = await minihotel_client.get_bookings()
    targets  = [
        b for b in bookings
        if b.get("checkin") == target_date
        and b.get("status") == "confirmed"
        and b.get("phone")
        and b.get("language")
    ]

    for booking in targets:
        try:
            rooms = booking.get("rooms", [])
            room  = rooms[0] if rooms else "desert"
            lang  = booking.get("language", "he")

            from app.integrations.whatsapp import get_room_display
            await whatsapp_service.send(
                to_phone   = booking["phone"],
                msg_type   = "pre_arrival",
                language   = lang,
                guest_name = booking["first_name"],
                room_name  = get_room_display(room, lang),
            )
            logger.info(f"[PreArrival] נשלח ל-{booking['first_name']} ({booking['id']})")
        except Exception as e:
            logger.error(f"[PreArrival] שגיאה ל-{booking.get('id')}: {e}")


async def task_send_checkin():
    """הודעות כניסה — קוד TTLock + מפה"""
    from app.integrations.minihotel import minihotel_client
    from app.integrations.ttlock import ttlock_client
    from app.integrations.whatsapp import whatsapp_service

    today    = datetime.now().strftime("%Y-%m-%d")
    bookings = await minihotel_client.get_bookings()
    targets  = [
        b for b in bookings
        if b.get("checkin") == today
        and b.get("status") == "confirmed"
        and b.get("phone")
        and b.get("language")
    ]

    for booking in targets:
        try:
            rooms = booking.get("rooms", [])

            # צור קוד TTLock
            checkin  = datetime.fromisoformat(booking["checkin"])
            checkout = datetime.fromisoformat(booking["checkout"])

            room_for_lock = rooms[0] if rooms else "desert"
            lock_result   = await ttlock_client.create_passcode(
                room          = room_for_lock,
                checkin       = checkin,
                checkout      = checkout,
                checkin_time  = booking.get("checkin_time",  "15:00"),
                checkout_time = booking.get("checkout_time", "11:00"),
            )

            code = lock_result["code"]

            # שלח הודעה
            await whatsapp_service.send_checkin(booking, code)

            logger.info(f"[CheckIn] נשלח ל-{booking['first_name']} קוד {code}# ({booking['id']})")
        except Exception as e:
            logger.error(f"[CheckIn] שגיאה ל-{booking.get('id')}: {e}")


async def task_send_checkout():
    """הודעות יציאה — סליקה (רק ישירות/אתר)"""
    from app.integrations.minihotel import minihotel_client
    from app.integrations.whatsapp import whatsapp_service

    today    = datetime.now().strftime("%Y-%m-%d")
    bookings = await minihotel_client.get_bookings()
    targets  = [
        b for b in bookings
        if b.get("checkout") == today
        and b.get("status") == "confirmed"
        and b.get("phone")
        and b.get("language")
    ]

    for booking in targets:
        try:
            result = await whatsapp_service.send_checkout(booking)
            if result:
                logger.info(f"[CheckOut] נשלח ל-{booking['first_name']} ({booking['id']})")
            else:
                logger.info(f"[CheckOut] דילוג על {booking['first_name']} (Airbnb/מזומן)")
        except Exception as e:
            logger.error(f"[CheckOut] שגיאה ל-{booking.get('id')}: {e}")


async def task_send_review():
    """הודעות ביקורת — 14:00 ביום היציאה"""
    from app.integrations.minihotel import minihotel_client
    from app.integrations.whatsapp import whatsapp_service

    today    = datetime.now().strftime("%Y-%m-%d")
    bookings = await minihotel_client.get_bookings()
    targets  = [
        b for b in bookings
        if b.get("checkout") == today
        and b.get("status") == "confirmed"
        and b.get("phone")
        and b.get("language")
    ]

    for booking in targets:
        try:
            lang = booking.get("language", "he")
            await whatsapp_service.send(
                to_phone   = booking["phone"],
                msg_type   = "review_request",
                language   = lang,
                guest_name = booking["first_name"],
            )
            logger.info(f"[Review] נשלח ל-{booking['first_name']} ({booking['id']})")
        except Exception as e:
            logger.error(f"[Review] שגיאה ל-{booking.get('id')}: {e}")


def start_scheduler():
    """הפעל את כל המשימות המתוזמנות"""

    # סנכרון MiniHotel — כל שעה
    scheduler.add_job(
        task_sync_minihotel,
        CronTrigger(minute=0),
        id="sync_minihotel"
    )

    # הודעות לפני הגעה — 09:00
    scheduler.add_job(
        task_send_pre_arrival,
        CronTrigger(hour=9, minute=0),
        id="pre_arrival"
    )

    # הודעות כניסה — 09:00
    scheduler.add_job(
        task_send_checkin,
        CronTrigger(hour=9, minute=0),
        id="checkin_code"
    )

    # הודעות יציאה — 09:00
    scheduler.add_job(
        task_send_checkout,
        CronTrigger(hour=9, minute=0),
        id="checkout_payment"
    )

    # הודעות ביקורת — 14:00
    scheduler.add_job(
        task_send_review,
        CronTrigger(hour=14, minute=0),
        id="review_request"
    )

    scheduler.start()
    logger.info("[Scheduler] כל המשימות הופעלו")
