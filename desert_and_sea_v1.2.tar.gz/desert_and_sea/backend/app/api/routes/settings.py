from fastapi import APIRouter
from pydantic import BaseModel
router = APIRouter()

class SettingsUpdate(BaseModel):
    checkin_time:     str | None = None
    checkout_time:    str | None = None
    pre_arrival_days: int | None = None

@router.get("")
async def get_settings():
    return {
        "checkin_time":     "15:00",
        "checkout_time":    "11:00",
        "pre_arrival_days": 2,
    }

@router.patch("")
async def update_settings(update: SettingsUpdate):
    # TODO: שמור ב-DB
    return {"status": "ok", "updated": update.dict(exclude_none=True)}
