from fastapi import APIRouter
router = APIRouter()

@router.get("/{booking_id}")
async def get_guest(booking_id: str):
    from app.integrations.minihotel import minihotel_client
    bookings = await minihotel_client.get_bookings()
    booking  = next((b for b in bookings if b.get("id") == booking_id), None)
    if not booking:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail="לא נמצא")
    return booking
