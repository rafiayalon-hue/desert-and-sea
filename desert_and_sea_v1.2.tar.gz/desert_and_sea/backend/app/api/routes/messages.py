from fastapi import APIRouter
from pydantic import BaseModel
from typing import Optional

router = APIRouter()

class SendMessageRequest(BaseModel):
    booking_id: str
    msg_type:   str    # booking_confirmation/pre_arrival/checkin_code/checkout_payment/review_request
    language:   str    # he/en/es/fr
    phone:      str

@router.post("/send")
async def send_message(req: SendMessageRequest):
    """שלח הודעה ידנית"""
    # TODO: implement with whatsapp_service
    return {"status": "ok", "message": f"הודעה {req.msg_type} נשלחה ל-{req.phone}"}

@router.get("/log/{booking_id}")
async def get_message_log(booking_id: str):
    """היסטוריית הודעות להזמנה"""
    return {"booking_id": booking_id, "messages": []}
