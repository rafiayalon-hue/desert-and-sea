"""
Bookings Router
GET  /api/bookings          — כל ההזמנות (עם פילטרים)
GET  /api/bookings/:id      — הזמנה ספציפית
POST /api/bookings/:id/sync — סנכרון ידני מ-MiniHotel
PATCH /api/bookings/:id     — עדכון שדות ידניים (שפה, תשלום, הערות)
POST /api/bookings/:id/backup — הוסף אורח גיבוי
POST /api/bookings/:id/backup/activate — אשר גיבוי → הזמנה רשמית
GET  /api/bookings/stats    — סטטיסטיקות תפוסה
"""
from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
from typing import Optional
from datetime import datetime, timedelta
from app.integrations.minihotel import minihotel_client

router = APIRouter()


class BookingUpdate(BaseModel):
    language:         Optional[str] = None   # he/en/es/fr
    payment_method:   Optional[str] = None   # credit_link/cash/bank
    payment_link:     Optional[str] = None   # לינק ישראכרט
    checkin_time:     Optional[str] = None   # override שעת כניסה
    checkout_time:    Optional[str] = None   # override שעת יציאה
    cancellation_tag: Optional[str] = None   # internal_block/guest_cancel/direct_switch
    internal_notes:   Optional[str] = None


class BackupGuestCreate(BaseModel):
    first_name: str
    last_name:  Optional[str] = ""
    phone:      str
    email:      Optional[str] = ""
    language:   Optional[str] = None
    notes:      Optional[str] = ""


@router.get("")
async def get_bookings(
    status:     Optional[str] = Query(None, description="confirmed/cancelled"),
    room:       Optional[str] = Query(None, description="desert/sea"),
    source:     Optional[str] = Query(None, description="direct/website/airbnb"),
    date_from:  Optional[str] = Query(None),
    date_to:    Optional[str] = Query(None),
    upcoming:   bool          = Query(False, description="רק הזמנות עתידיות"),
):
    """שלוף הזמנות עם פילטרים"""
    df = datetime.fromisoformat(date_from) if date_from else datetime.now()
    dt = datetime.fromisoformat(date_to)   if date_to   else df + timedelta(days=180)

    bookings = await minihotel_client.get_bookings(date_from=df, date_to=dt)

    # פילטרים
    if status:
        bookings = [b for b in bookings if b.get("status") == status]
    if room:
        bookings = [b for b in bookings if room in b.get("rooms", [])]
    if source:
        bookings = [b for b in bookings if b.get("source") == source]
    if upcoming:
        today = datetime.now().strftime("%Y-%m-%d")
        bookings = [b for b in bookings if b.get("checkin", "") >= today]

    # מיין לפי תאריך כניסה
    bookings.sort(key=lambda b: b.get("checkin", ""))

    return {
        "total":    len(bookings),
        "bookings": bookings
    }


@router.get("/stats")
async def get_stats():
    """סטטיסטיקות תפוסה — ללא ספירה כפולה"""
    return await minihotel_client.get_occupancy_stats()


@router.get("/today")
async def get_today():
    """הגעות ועזיבות היום"""
    today = datetime.now().strftime("%Y-%m-%d")
    bookings = await minihotel_client.get_bookings()

    arrivals   = [b for b in bookings if b.get("checkin")  == today and b.get("status") == "confirmed"]
    departures = [b for b in bookings if b.get("checkout") == today and b.get("status") == "confirmed"]

    return {
        "date":       today,
        "arrivals":   arrivals,
        "departures": departures,
    }


@router.get("/{booking_id}")
async def get_booking(booking_id: str):
    """הזמנה ספציפית לפי ID"""
    bookings = await minihotel_client.get_bookings()
    booking  = next((b for b in bookings if b.get("id") == booking_id), None)
    if not booking:
        raise HTTPException(status_code=404, detail="הזמנה לא נמצאה")
    return booking


@router.post("/{booking_id}/sync")
async def sync_booking(booking_id: str):
    """סנכרון ידני של הזמנה ספציפית מ-MiniHotel"""
    # TODO: לאחר קבלת endpoints מיובל
    return {"status": "ok", "message": "סנכרון הושלם", "booking_id": booking_id}


@router.patch("/{booking_id}")
async def update_booking(booking_id: str, update: BookingUpdate):
    """
    עדכון שדות ידניים — שפה, תשלום, הערות, שעות override
    שדות אלו מנוהלים בדשבורד בלבד ולא נשלחים ל-MiniHotel
    """
    # TODO: שמור ב-DB
    return {
        "status":     "ok",
        "booking_id": booking_id,
        "updated":    update.dict(exclude_none=True)
    }


@router.post("/{booking_id}/backup")
async def add_backup_guest(booking_id: str, backup: BackupGuestCreate):
    """הוסף אורח גיבוי להזמנה"""
    # TODO: שמור ב-DB
    return {
        "status":     "ok",
        "booking_id": booking_id,
        "backup":     backup.dict()
    }


@router.post("/{booking_id}/backup/activate")
async def activate_backup(booking_id: str):
    """
    אשר גיבוי → הזמנה רשמית
    1. רשום הזמנה ב-MiniHotel
    2. צור קוד TTLock
    3. שלח הודעת אישור
    """
    # TODO: implement
    return {"status": "ok", "message": "גיבוי הופעל בהצלחה"}


@router.post("/sync/all")
async def sync_all():
    """סנכרון כל ההזמנות מ-MiniHotel (6 חודשים קדימה)"""
    bookings = await minihotel_client.get_bookings(
        date_from=datetime.now(),
        date_to=datetime.now() + timedelta(days=180)
    )
    return {
        "status":  "ok",
        "synced":  len(bookings),
        "message": f"סונכרנו {len(bookings)} הזמנות"
    }
