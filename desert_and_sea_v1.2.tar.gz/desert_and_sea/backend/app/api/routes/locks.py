from fastapi import APIRouter
router = APIRouter()

@router.get("/status")
async def get_locks_status():
    from app.integrations.ttlock import ttlock_client
    desert = await ttlock_client.get_lock_status("desert")
    sea    = await ttlock_client.get_lock_status("sea")
    return {"desert": desert, "sea": sea}

@router.post("/{room}/generate")
async def generate_code(room: str, booking_id: str, checkin: str, checkout: str):
    from app.integrations.ttlock import ttlock_client
    from datetime import datetime
    result = await ttlock_client.create_passcode(
        room=room,
        checkin=datetime.fromisoformat(checkin),
        checkout=datetime.fromisoformat(checkout),
    )
    return result
