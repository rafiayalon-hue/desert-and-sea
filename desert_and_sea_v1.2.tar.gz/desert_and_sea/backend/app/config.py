from pydantic_settings import BaseSettings
from typing import Optional

class Settings(BaseSettings):
    # MiniHotel
    MINIHOTEL_URL: str = "https://api2.minihotel.cloud"
    MINIHOTEL_SANDBOX_URL: str = "https://sandbox.minihotel.cloud"
    MINIHOTEL_USERNAME: str = ""
    MINIHOTEL_PASSWORD: str = ""
    MINIHOTEL_HOTEL_ID: str = ""
    MINIHOTEL_USE_SANDBOX: bool = True

    # TTLock
    TTLOCK_CLIENT_ID: str = ""
    TTLOCK_ACCESS_TOKEN: str = ""

    # Twilio WhatsApp
    TWILIO_ACCOUNT_SID: str = ""
    TWILIO_AUTH_TOKEN: str = ""
    TWILIO_FROM_NUMBER: str = "whatsapp:+14155238886"  # Sandbox number

    # Database
    DATABASE_URL: str = "postgresql+asyncpg://user:password@localhost/desert_and_sea"
    REDIS_URL: str = "redis://localhost:6379"

    # App
    SECRET_KEY: str = "change-me-in-production"
    USE_MOCK_DATA: bool = True  # True עד שה-API עובד

    # Check-in / Check-out defaults (ניתן לשינוי מה-UI)
    DEFAULT_CHECKIN_TIME: str = "15:00"
    DEFAULT_CHECKOUT_TIME: str = "11:00"

    # Parking map image path
    PARKING_MAP_PATH: str = "assets/parking_map.jpg"

    # Isracard 360 (גרסה 2)
    ISRACARD_API_KEY: Optional[str] = None

    class Config:
        env_file = ".env"

settings = Settings()
