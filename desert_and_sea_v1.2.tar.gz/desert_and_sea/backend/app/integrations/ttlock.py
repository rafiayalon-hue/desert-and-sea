"""
TTLock Integration
------------------
EU Server: https://euapi.ttlock.com
קוד: 4 ספרות אקראיות + # בסוף
סוג: passcode type=3 (timed — פעיל בין תאריכים)

ROOM_LOCK_MAP: יש להגדיר ידנית לאחר חיבור מנעולים
"""
import httpx
import random
import time
from datetime import datetime
from app.config import settings

TTLOCK_BASE = "https://euapi.ttlock.com"

# מיפוי חדר → Lock ID (יש לעדכן ידנית לאחר הגדרה ב-TTLock)
ROOM_LOCK_MAP = {
    "desert": None,  # TODO: הכנס Lock ID של צימר מדבר
    "sea":    None,  # TODO: הכנס Lock ID של צימר ים
}


class TTLockClient:

    def __init__(self):
        self.client_id    = settings.TTLOCK_CLIENT_ID
        self.access_token = settings.TTLOCK_ACCESS_TOKEN

    def generate_code(self) -> str:
        """צור קוד 4 ספרות אקראי"""
        return str(random.randint(1000, 9999))

    def _datetime_to_ms(self, dt: datetime) -> int:
        """המר datetime ל-milliseconds (פורמט TTLock)"""
        return int(dt.timestamp() * 1000)

    async def create_passcode(
        self,
        room: str,
        checkin: datetime,
        checkout: datetime,
        checkin_time: str  = "15:00",
        checkout_time: str = "11:00",
    ) -> dict:
        """
        צור קוד כניסה מוגבל זמן ל-TTLock
        מחזיר: {"code": "2302", "passcode_id": "...", "valid_from": ..., "valid_to": ...}
        """
        lock_id = ROOM_LOCK_MAP.get(room)
        if not lock_id:
            # Mock — מנעול לא מוגדר עדיין
            code = self.generate_code()
            return {
                "code":        code,
                "passcode_id": f"mock_{code}",
                "valid_from":  checkin.isoformat(),
                "valid_to":    checkout.isoformat(),
                "mock":        True
            }

        # חשב זמני תחילה וסיום מדויקים
        h_in,  m_in  = map(int, checkin_time.split(":"))
        h_out, m_out = map(int, checkout_time.split(":"))

        start_dt = checkin.replace(hour=h_in,  minute=m_in,  second=0, microsecond=0)
        end_dt   = checkout.replace(hour=h_out, minute=m_out, second=0, microsecond=0)

        code = self.generate_code()

        payload = {
            "clientId":    self.client_id,
            "accessToken": self.access_token,
            "lockId":      lock_id,
            "keyboardPwd": code,
            "keyboardPwdType": 3,           # timed passcode
            "startDate":   self._datetime_to_ms(start_dt),
            "endDate":     self._datetime_to_ms(end_dt),
            "date":        int(time.time() * 1000),
        }

        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.post(
                f"{TTLOCK_BASE}/v3/keyboardPwd/add",
                data=payload
            )
            resp.raise_for_status()
            data = resp.json()

        if data.get("errcode") != 0:
            raise Exception(f"TTLock error: {data.get('errmsg')}")

        return {
            "code":        code,
            "passcode_id": str(data.get("keyboardPwdId")),
            "valid_from":  start_dt.isoformat(),
            "valid_to":    end_dt.isoformat(),
            "mock":        False
        }

    async def delete_passcode(self, room: str, passcode_id: str) -> bool:
        """מחק קוד (בעת ביטול הזמנה)"""
        lock_id = ROOM_LOCK_MAP.get(room)
        if not lock_id or passcode_id.startswith("mock_"):
            return True

        payload = {
            "clientId":      self.client_id,
            "accessToken":   self.access_token,
            "lockId":        lock_id,
            "keyboardPwdId": passcode_id,
            "date":          int(time.time() * 1000),
        }

        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.post(
                f"{TTLOCK_BASE}/v3/keyboardPwd/delete",
                data=payload
            )
            data = resp.json()

        return data.get("errcode") == 0

    async def get_lock_status(self, room: str) -> dict:
        """בדוק סטטוס מנעול"""
        lock_id = ROOM_LOCK_MAP.get(room)
        if not lock_id:
            return {"room": room, "status": "lock_not_configured", "mock": True}

        payload = {
            "clientId":    self.client_id,
            "accessToken": self.access_token,
            "lockId":      lock_id,
            "date":        int(time.time() * 1000),
        }

        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.post(
                f"{TTLOCK_BASE}/v3/lock/queryOpenState",
                data=payload
            )
            data = resp.json()

        return {
            "room":   room,
            "status": "open" if data.get("state") == 1 else "closed",
            "mock":   False
        }


ttlock_client = TTLockClient()
