"""
WhatsApp Messaging Service — Twilio
------------------------------------
5 הודעות × 4 שפות
הודעה 3 (כניסה) נשלחת עם תמונת מפת חניה
הודעה 4 (יציאה) רק להזמנות ישירות/אתר
"""
from twilio.rest import Client
from datetime import datetime
from pathlib import Path
from app.config import settings

PARKING_MAP_PATH = Path(__file__).parent.parent.parent / "assets" / "parking_map.jpg"
PARKING_MAP_URL  = "https://desert-sea.co.il/assets/parking_map.jpg"  # URL ציבורי למפה


# ═══════════════════════════════════════════════════════════════
# TEMPLATES — 5 הודעות × 4 שפות
# ═══════════════════════════════════════════════════════════════

TEMPLATES = {

    # ── הודעה 1: אישור הזמנה ──────────────────────────────────
    "booking_confirmation": {
        "he": """שלום {guest_name}, איזה כיף שהצטרפתם אלינו! 🎉

שמחים לאשר את הזמנתכם ל{room_name} בתאריכים {checkin} - {checkout}.

אנחנו זמינים למתן המלצות באזור, ניתן גם להיכנס לאתר שלנו להתעדכן.
https://desert-sea.co.il/

מדבר וים — מקום של חופש 🕊️""",

        "en": """Hi {guest_name}, so happy you're joining us! 🎉

We're pleased to confirm your booking for the {room_name} cabin, {checkin} - {checkout}.

We're happy to give recommendations for the area. Visit our website for more info.
https://desert-sea.co.il/

Desert and Sea — A Place of Freedom 🕊️""",

        "es": """¡Hola {guest_name}, qué alegría que os unáis a nosotros! 🎉

Confirmamos vuestra reserva para la cabaña {room_name}, del {checkin} al {checkout}.

Estamos disponibles para recomendaciones. También podéis visitar nuestra web.
https://desert-sea.co.il/

Desert and Sea — Un lugar de libertad 🕊️""",

        "fr": """Bonjour {guest_name}, quelle joie de vous accueillir ! 🎉

Nous confirmons votre réservation pour le chalet {room_name} du {checkin} au {checkout}.

Nous sommes disponibles pour des recommandations. Consultez aussi notre site.
https://desert-sea.co.il/

Desert and Sea — Un endroit de liberté 🕊️""",
    },

    # ── הודעה 2: לפני הגעה (יומיים מראש) ─────────────────────
    "pre_arrival": {
        "he": """שלום {guest_name}! 👋
מחכים לכם בעוד יומיים ב{room_name} 🏜️🌊

ביום הגעתכם תקבלו קוד כניסה והוראות הגעה מפורטות.

לכל שאלה — אנחנו כאן!
מדבר וים 🕊️""",

        "en": """Hi {guest_name}! 👋
We're looking forward to welcoming you in 2 days at the {room_name} cabin 🏜️🌊

On the day of your arrival, you'll receive your entry code and detailed directions.

Any questions? We're here!
Desert and Sea 🕊️""",

        "es": """¡Hola {guest_name}! 👋
¡Os esperamos en 2 días en la cabaña {room_name}! 🏜️🌊

El día de vuestra llegada recibiréis el código de entrada e instrucciones detalladas.

¿Alguna pregunta? ¡Aquí estamos!
Desert and Sea 🕊️""",

        "fr": """Bonjour {guest_name} ! 👋
Nous vous attendons dans 2 jours au chalet {room_name} 🏜️🌊

Le jour de votre arrivée, vous recevrez votre code d'entrée et les instructions détaillées.

Des questions ? Nous sommes là !
Desert and Sea 🕊️""",
    },

    # ── הודעה 3: יום כניסה — קוד + הוראות + מפה ──────────────
    "checkin_code": {
        "he": """ברוכים הבאים למדבר וים 🏜️🌊

🗝️ הקוד שלכם ל{room_name} הוא {code}#
פעיל מ-{checkin} שעה {checkin_time} עד {checkout} שעה {checkout_time}

🎯 כתובת בווייז: חניית אורחים, עין גדי

הוראות הגעה:
חנו במגרש חניה צרויה. עלו למפלס השני או השלישי בחניה לא משולטת. לכו לסוף המפלס, לצד הרחוק מההר. קחו ימינה במשתלבות, רדו במדרכה כ-40 מטר עד הפניה שמאלה לרחוב מעלה צרויה (מדרכה רחבה). בפניה השנייה מהשביל הראשי, לאחר כ-70 מטר קחו ימינה. אנחנו הבית השני משמאל, הצימר במעלה המדרגות.

🛜 WiFi: midbar&yam  |  סיסמה: 1122334455

שתהיה לכם חופשה מעולה! 🌟

📞 רפי 058-4222666
📞 אבישג 052-3960773

מדבר וים — מקום של חופש 🕊️
desert-sea.co.il/#contact""",

        "en": """Welcome to Desert and Sea! 🏜️🌊

🗝️ Your entry code for the {room_name} cabin is {code}#
Valid from {checkin} at {checkin_time} until {checkout} at {checkout_time}

🎯 Waze: Guests Parking, Ein Gedi

Directions:
Park at Tzruya parking lot, 2nd or 3rd level (unsignposted). Walk to the far end away from the mountain, turn right, go down the sidewalk ~40m to the left turn onto Ma'ale Tzruya St (wide sidewalk). At the second turn, after ~70m turn right. We are the second house on the left — the cabin is up the stairs.

🛜 WiFi: midbar&yam  |  Password: 1122334455

Have a wonderful vacation! 🌟

📞 Rafi: 058-4222666
📞 Avishag: 052-3960773

Desert and Sea — A Place of Freedom 🕊️
desert-sea.co.il/#contact""",

        "es": """¡Bienvenidos a Desert and Sea! 🏜️🌊

🗝️ Vuestro código para la cabaña {room_name} es {code}#
Válido del {checkin} a las {checkin_time} hasta el {checkout} a las {checkout_time}

🎯 Waze: Guests Parking, Ein Gedi

Cómo llegar:
Estacione en el aparcamiento Tzruya, nivel 2 o 3. Camine hasta el extremo alejado de la montaña, gire a la derecha, baje ~40m hasta girar a la izquierda en Ma'ale Tzruya St. Al segundo giro, después de ~70m gire a la derecha. Somos la segunda casa a la izquierda — la cabaña está subiendo las escaleras.

🛜 WiFi: midbar&yam  |  Contraseña: 1122334455

¡Que tengan unas vacaciones increíbles! 🌟

📞 Rafi: 058-4222666
📞 Avishag: 052-3960773

Desert and Sea — Un lugar de libertad 🕊️
desert-sea.co.il/#contact""",

        "fr": """Bienvenue à Desert and Sea ! 🏜️🌊

🗝️ Votre code pour le chalet {room_name} est {code}#
Valide du {checkin} à {checkin_time} jusqu'au {checkout} à {checkout_time}

🎯 Waze : Guests Parking, Ein Gedi

Instructions d'accès :
Garez-vous au parking Tzruya, 2e ou 3e niveau. Marchez jusqu'au bout côté opposé à la montagne, tournez à droite, descendez ~40m jusqu'au virage à gauche sur Ma'ale Tzruya St. Au deuxième virage, après ~70m tournez à droite. Nous sommes la deuxième maison à gauche — le chalet est en haut des escaliers.

🛜 WiFi : midbar&yam  |  Mot de passe : 1122334455

Passez d'excellentes vacances ! 🌟

📞 Rafi : 058-4222666
📞 Avishag : 052-3960773

Desert and Sea — Un endroit de liberté 🕊️
desert-sea.co.il/#contact""",
    },

    # ── הודעה 4: יום עזיבה — סליקה ───────────────────────────
    "checkout_payment": {
        "he": """בוקר טוב {guest_name} ☀️
תודה שבחרתם להתארח אצלנו!

לפני היציאה:
🕐 צ'ק אאוט עד שעה {checkout_time}
🔑 זכרו לכבות אורות ומזגנים
🗄️ בדקו שלא שכחתם דברים בארונות או במקרר
🧹 נסו להשאיר את הצימר מסודר

💳 לתשלום על שהייתכם (₪{price}):
{payment_link}

היה לכם נעים? נשמח לחוות דעתכם! 😊

מדבר וים — מקום של חופש 🏨""",

        "en": """Good morning {guest_name} ☀️
Thank you for staying with us!

Before you check out:
🕐 Check-out by {checkout_time}
🔑 Please turn off lights and air conditioning
🗄️ Check you haven't left anything in the wardrobes or fridge
🧹 Please leave the cabin tidy

💳 Payment for your stay (₪{price}):
{payment_link}

Hope you enjoyed it! We'd love your feedback 😊

Desert and Sea — A Place of Freedom 🏨""",

        "es": """Buenos días {guest_name} ☀️
¡Gracias por alojarse con nosotros!

Antes de salir:
🕐 Check-out antes de las {checkout_time}
🔑 Recordad apagar luces y aire acondicionado
🗄️ Comprobad que no olvidáis nada en los armarios o en la nevera
🧹 Intentad dejar la cabaña ordenada

💳 Pago por vuestra estancia (₪{price}):
{payment_link}

¿Lo habéis pasado bien? ¡Nos encantaría vuestra opinión! 😊

Desert and Sea — Un lugar de libertad 🏨""",

        "fr": """Bonjour {guest_name} ☀️
Merci d'avoir séjourné chez nous !

Avant de partir :
🕐 Check-out avant {checkout_time}
🔑 Pensez à éteindre les lumières et la climatisation
🗄️ Vérifiez que vous n'avez rien oublié dans les armoires ou le réfrigérateur
🧹 Essayez de laisser le chalet en ordre

💳 Paiement pour votre séjour (₪{price}) :
{payment_link}

Vous avez passé un bon moment ? Votre avis nous ferait plaisir ! 😊

Desert and Sea — Un endroit de liberté 🏨""",
    },

    # ── הודעה 5: ביקורת ───────────────────────────────────────
    "review_request": {
        "he": """שלום {guest_name}! 💙
תודה רבה על הביקור אצלנו!

נשמח מאוד אם תוכלו:
⭐ להעניק לנו ציון בגוגל
📝 לכתוב כמה מילים על החוויה
📲 להמליץ לחברים

זה עוזר לנו המון!
מחכים לראותכם שוב בקרוב 🤗

🏨 מדבר וים — מקום של חופש
https://g.page/r/CZ9WMsn3UGPKEAI/review""",

        "en": """Hi {guest_name}! 💙
Thank you so much for staying with us!

We'd love it if you could:
⭐ Give us a rating on Google
📝 Write a few words about your experience
📲 Recommend us to friends

It means the world to us!
Hope to see you again soon 🤗

🏨 Desert and Sea — A Place of Freedom
https://g.page/r/CZ9WMsn3UGPKEAI/review""",

        "es": """¡Hola {guest_name}! 💙
¡Muchas gracias por vuestra visita!

Nos encantaría que pudierais:
⭐ Darnos una valoración en Google
📝 Escribir unas palabras sobre la experiencia
📲 Recomendarnos a amigos

¡Nos ayuda muchísimo!
¡Esperamos veros pronto! 🤗

🏨 Desert and Sea — Un lugar de libertad
https://g.page/r/CZ9WMsn3UGPKEAI/review""",

        "fr": """Bonjour {guest_name} ! 💙
Merci beaucoup pour votre visite !

Nous serions ravis si vous pouviez :
⭐ Nous donner une note sur Google
📝 Écrire quelques mots sur votre expérience
📲 Nous recommander à vos amis

Cela nous aide énormément !
Nous espérons vous revoir bientôt ! 🤗

🏨 Desert and Sea — Un endroit de liberté
https://g.page/r/CZ9WMsn3UGPKEAI/review""",
    },
}


def get_room_display(room: str, language: str) -> str:
    """שם החדר לפי שפה"""
    names = {
        "desert": {"he": "מדבר (דלת חומה)",  "en": "Desert (brown door)", "es": "Desierto (puerta marrón)", "fr": "Désert (porte marron)"},
        "sea":    {"he": "ים (דלת כחולה)",    "en": "Sea (blue door)",     "es": "Mar (puerta azul)",        "fr": "Mer (porte bleue)"},
    }
    return names.get(room, {}).get(language, room)


class WhatsAppService:

    def __init__(self):
        self.client      = Client(settings.TWILIO_ACCOUNT_SID, settings.TWILIO_AUTH_TOKEN)
        self.from_number = settings.TWILIO_FROM_NUMBER

    def render(self, msg_type: str, language: str, **kwargs) -> str:
        template = TEMPLATES.get(msg_type, {}).get(language)
        if not template:
            raise ValueError(f"Template not found: {msg_type}/{language}")
        return template.format(**kwargs)

    async def send(
        self,
        to_phone:  str,
        msg_type:  str,
        language:  str,
        media_url: str | None = None,
        **kwargs
    ) -> dict:
        """שלח הודעת WhatsApp"""
        body = self.render(msg_type, language, **kwargs)
        to   = f"whatsapp:{to_phone}" if not to_phone.startswith("whatsapp:") else to_phone

        params = {
            "from_": self.from_number,
            "to":    to,
            "body":  body,
        }
        if media_url:
            params["media_url"] = [media_url]

        message = self.client.messages.create(**params)

        return {
            "sid":    message.sid,
            "status": message.status,
            "to":     to_phone,
            "type":   msg_type,
        }

    async def send_checkin(self, booking: dict, code: str) -> dict:
        """הודעת כניסה + מפת חניה"""
        lang   = booking.get("language", "he")
        rooms  = booking.get("rooms", [])
        room   = rooms[0] if rooms else "desert"

        return await self.send(
            to_phone     = booking["phone"],
            msg_type     = "checkin_code",
            language     = lang,
            media_url    = PARKING_MAP_URL,
            guest_name   = booking["first_name"],
            room_name    = get_room_display(room, lang),
            code         = code,
            checkin      = booking["checkin"],
            checkout     = booking["checkout"],
            checkin_time = booking.get("checkin_time",  "15:00"),
            checkout_time= booking.get("checkout_time", "11:00"),
        )

    async def send_checkout(self, booking: dict) -> dict | None:
        """הודעת יציאה + סליקה — רק להזמנות ישירות/אתר"""
        if booking.get("source") == "airbnb":
            return None  # לא שולחים ל-Airbnb
        if booking.get("payment_method") in ("cash", "bank"):
            return None  # מזומן/העברה — לא צריך לינק

        lang = booking.get("language", "he")
        rooms = booking.get("rooms", [])
        room  = rooms[0] if rooms else "desert"

        return await self.send(
            to_phone      = booking["phone"],
            msg_type      = "checkout_payment",
            language      = lang,
            guest_name    = booking["first_name"],
            room_name     = get_room_display(room, lang),
            checkout_time = booking.get("checkout_time", "11:00"),
            price         = int(booking.get("total_price", 0)),
            payment_link  = booking.get("payment_link", ""),
        )


whatsapp_service = WhatsAppService()
