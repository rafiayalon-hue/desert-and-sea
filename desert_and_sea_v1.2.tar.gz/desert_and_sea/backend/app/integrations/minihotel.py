"""
MiniHotel Integration — Content API (XML-based)
-------------------------------------------------
Sandbox:    https://sandbox.minihotel.cloud
Production: https://api2.minihotel.cloud

Endpoints מאושרים מיובל שטוחמר (26/2/2026):
  getRooms: /agents/ws/settings/rooms/RoomsMain.asmx/getRooms
"""
import json
import httpx
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta
from pathlib import Path
from calendar import monthrange
from app.config import settings

MOCK_DATA_PATH = Path(__file__).parent.parent.parent / "mock_data" / "mock_bookings.json"

ENDPOINTS = {
    "getRooms":              "agents/ws/settings/rooms/RoomsMain.asmx/getRooms",
    "getRoomTypes":          "agents/ws/settings/rooms/RoomsMain.asmx/getRoomTypes",
    "GetReservationKey":     "agents/ws/SCI/SCI.asmx/GetReservationKey",
    "UpdateReservation":     "agents/ws/SCI/SCI.asmx/UpdateReservation",
    "GetReservationBalance": "agents/ws/SCI/SCI.asmx/GetReservationBalance",
    "ChangeReservationStatus": "agents/ws/SCI/SCI.asmx/ChangeReservationStatus",
}


class MiniHotelClient:

    def __init__(self):
        self.base_url = (
            settings.MINIHOTEL_SANDBOX_URL
            if settings.MINIHOTEL_USE_SANDBOX
            else settings.MINIHOTEL_URL
        )
        self.username = settings.MINIHOTEL_USERNAME
        self.password = settings.MINIHOTEL_PASSWORD
        self.hotel_id = settings.MINIHOTEL_HOTEL_ID
        self.use_mock = settings.USE_MOCK_DATA

    def _wrap_request(self, function_name: str, body: str) -> str:
        return f"""<?xml version="1.0" encoding="UTF-8"?>
<Request>
    <Settings name="{function_name}">
        <Authentication username="{self.username}" password="{self.password}"/>
        <Hotel id="{self.hotel_id}" />
        {body}
    </Settings>
</Request>"""

    async def _post(self, function_name: str, body: str = "") -> ET.Element:
        endpoint = ENDPOINTS.get(function_name)
        if not endpoint:
            raise ValueError(f"Unknown function: {function_name}")
        xml_body = self._wrap_request(function_name, body)
        url = f"{self.base_url}/{endpoint}"
        async with httpx.AsyncClient(timeout=30) as client:
            response = await client.post(
                url,
                content=xml_body.encode("utf-8"),
                headers={"Content-Type": "text/xml; charset=utf-8"}
            )
            response.raise_for_status()
            return ET.fromstring(response.text)

    def _load_mock(self) -> list:
        if MOCK_DATA_PATH.exists():
            with open(MOCK_DATA_PATH, encoding="utf-8") as f:
                return json.load(f)
        return []

    def _normalize_rooms(self, room_str: str) -> list:
        rooms = []
        for r in (room_str or "").split(","):
            r = r.strip()
            if r in ("Sesert", "sesert", "Desert", "desert"):
                rooms.append("desert")
            elif r in ("Sea", "sea"):
                rooms.append("sea")
            elif r in ("Des_Sea", "des_sea"):
                rooms.extend(["desert", "sea"])
        return rooms

    def _normalize_source(self, source: str) -> str:
        if not source or source == "01":
            return "direct"
        if source in ("BOENGINE", "BE"):
            return "website"
        if source == "AIRBNB":
            return "airbnb"
        return "direct"

    async def get_rooms(self) -> list:
        if self.use_mock:
            return [
                {"id": "desert", "name": "צימר מדבר", "door_color": "חומה"},
                {"id": "sea",    "name": "צימר ים",   "door_color": "כחולה"},
            ]
        root = await self._post("getRooms", "<room_number></room_number>")
        rooms = []
        for rm in root.findall(".//rnm_struct_room"):
            rooms.append({
                "id":        rm.findtext("rm_number", ""),
                "rm_number": rm.findtext("rm_number", ""),
                "rm_type":   rm.findtext("rm_type", ""),
                "rm_status": rm.findtext("rm_status", ""),
                "rm_color":  rm.findtext("rm_color", ""),
            })
        return rooms

    async def get_bookings(self, date_from=None, date_to=None) -> list:
        if self.use_mock:
            return self._get_mock_bookings(date_from, date_to)
        return await self._get_live_bookings(date_from, date_to)

    def _get_mock_bookings(self, date_from, date_to) -> list:
        bookings = self._load_mock()
        if date_from:
            bookings = [b for b in bookings if (b.get("checkin") or "") >= date_from.strftime("%Y-%m-%d")]
        if date_to:
            bookings = [b for b in bookings if (b.get("checkin") or "") <= date_to.strftime("%Y-%m-%d")]
        return bookings

    async def _get_live_bookings(self, date_from, date_to) -> list:
        if not date_from:
            date_from = datetime.now()
        if not date_to:
            date_to = date_from + timedelta(days=180)
        body = f"""
            <dateFrom>{date_from.strftime('%Y-%m-%d')}</dateFrom>
            <dateTo>{date_to.strftime('%Y-%m-%d')}</dateTo>
        """
        root = await self._post("GetReservationKey", body)
        # TODO: parse XML לפי response אמיתי מה-Sandbox
        return []

    def _month_label(self, dt: datetime) -> str:
        months_he = ["ינואר","פברואר","מרץ","אפריל","מאי","יוני",
                     "יולי","אוגוסט","ספטמבר","אוקטובר","נובמבר","דצמבר"]
        return f"{months_he[dt.month - 1]} {dt.year}"

    async def get_occupancy_stats(self) -> dict:
        """תפוסה: חודש נוכחי + 2 חודשים קדימה — ללא ספירה כפולה"""
        now = datetime.now()
        # שלוף 3 חודשים קדימה
        date_from = now.replace(day=1)
        date_to   = (date_from + timedelta(days=93)).replace(day=28)
        all_b     = await self.get_bookings(date_from=date_from, date_to=date_to)
        confirmed = [b for b in all_b if b.get("status") == "confirmed"]

        months = []
        for delta in range(3):
            m_date   = (date_from + timedelta(days=32 * delta)).replace(day=1)
            m_str    = m_date.strftime("%Y-%m")
            days_in  = monthrange(m_date.year, m_date.month)[1]

            desert_n = sea_n = revenue = bookings_count = 0

            for b in confirmed:
                checkin  = b.get("checkin",  "") or ""
                checkout = b.get("checkout", "") or ""
                # הזמנה רלוונטית לחודש — כניסה או יציאה בחודש
                if checkin[:7] != m_str and checkout[:7] != m_str:
                    continue

                rooms  = b.get("rooms", [])
                nights = b.get("nights", 0) or 0
                price  = b.get("total_price", 0) or 0

                if b.get("is_combined_booking"):
                    desert_n += nights
                    sea_n    += nights
                elif "desert" in rooms:
                    desert_n += nights
                elif "sea" in rooms:
                    sea_n += nights

                revenue        += price
                bookings_count += 1

            months.append({
                "month":          m_str,
                "month_label":    self._month_label(m_date),
                "days_in_month":  days_in,
                "desert_nights":  desert_n,
                "sea_nights":     sea_n,
                "desert_pct":     round(desert_n / days_in * 100) if days_in else 0,
                "sea_pct":        round(sea_n    / days_in * 100) if days_in else 0,
                "revenue":        int(revenue),
                "bookings_count": bookings_count,
            })

        return {
            "months":        months,
            "confirmed_total": len(confirmed),
            "desert_total":  sum(m["desert_nights"] for m in months),
            "sea_total":     sum(m["sea_nights"]    for m in months),
            "revenue_total": sum(m["revenue"]       for m in months),
        }

    async def get_simple_stats(self) -> dict:
        """סטטיסטיקות בסיסיות ל-Dashboard"""
        bookings = await self.get_bookings(
            date_from=datetime.now(),
            date_to=datetime.now() + timedelta(days=180)
        )
        confirmed = [b for b in bookings if b.get("status") == "confirmed"]
        today     = datetime.now().strftime("%Y-%m-%d")

        return {
            "confirmed_total": len(confirmed),
            "arrivals_today":  [b for b in confirmed if b.get("checkin")  == today],
            "departures_today":[b for b in confirmed if b.get("checkout") == today],
            "desert_bookings": [b for b in confirmed if "desert" in b.get("rooms", [])],
            "sea_bookings":    [b for b in confirmed if "sea"    in b.get("rooms", [])],
        }


minihotel_client = MiniHotelClient()
