# מדבר וים — דשבורד ניהול

## הרצה מהירה

### דרישות
- [Docker Desktop](https://www.docker.com/products/docker-desktop/)

### הרצה
```bash
# בתיקיית הפרויקט:
docker compose up
```

### גישה
- **דשבורד**: http://localhost:5173
- **API**: http://localhost:8000
- **תיעוד API**: http://localhost:8000/docs

---

## מצב נוכחי

| רכיב | מצב |
|------|------|
| Frontend | ✅ עובד על Mock Data |
| Backend | ✅ מוכן — ממתין לendpoints מיובל |
| MiniHotel API | 🟡 ממתין לתשובת יובל |
| TTLock | 🟡 ממתין לחיבור מנעולים |
| Twilio WhatsApp | 🟡 ממתין להגדרת credentials |
| Database | ✅ PostgreSQL מוכן |

## מעבר ל-Live (אחרי תשובת יובל)
1. עדכן `backend/.env.example` → `backend/.env` עם credentials אמיתיים
2. שנה `USE_MOCK_DATA=false` ב-.env
3. עדכן endpoints ב-`backend/app/integrations/minihotel.py`
4. הרץ מחדש: `docker compose restart backend`
